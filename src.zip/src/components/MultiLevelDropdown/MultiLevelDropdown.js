import React, { useState } from "react";
import { Dropdown, ButtonGroup } from "react-bootstrap";
import dropdownOptions from "./dropdownData"; // Import dropdown structure
import "./MultiLevelDropdown.css";

const MultiLevelDropdown = () => {
  const [openMenus, setOpenMenus] = useState({});

  // Toggle sub-dropdown visibility when clicked
  const handleToggle = (key) => {
    setOpenMenus((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Recursive function to render dropdown items
  const renderDropdown = (options = [], level = 0) => {
    return (
      <ul className={`dropdown-menu dropdown-level-${level}`}>
        {options.map((option, index) => (
          <li key={index} className="dropdown-item-container">
            <div
              className="dropdown-item"
              onClick={() => option.subOptions && handleToggle(option.label)}
            >
              {option.label}
              {option.subOptions && <span className="arrow">➤</span>}
            </div>
            {option.subOptions && openMenus[option.label] && (
              <ul className="submenu">{renderDropdown(option.subOptions, level + 1)}</ul>
            )}
          </li>
        ))}
      </ul>
    );
  };

  return (
    <div className="multi-level-dropdown-container">
      <Dropdown as={ButtonGroup}>
        <Dropdown.Toggle variant="light" className="dropdown-toggle">
          Disposition
        </Dropdown.Toggle>
        <Dropdown.Menu>{renderDropdown(dropdownOptions)}</Dropdown.Menu>
      </Dropdown>
    </div>
  );
};

export default MultiLevelDropdown;
