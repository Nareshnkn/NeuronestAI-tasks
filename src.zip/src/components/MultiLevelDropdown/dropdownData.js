const dropdownOptions = [
    {
      label: "Interested",
      subOptions: [
        { label: "Project 1" },
        { label: "Project 2" },
        { label: "Project 3" },
        {
          label: "Executive",
          subOptions: [
            { label: "Executive 1" },
            { label: "Executive 2" },
            { label: "Executive 3" },
          ],
        },
      ],
    },
    { label: "Not Interested" },
    { label: "Call Back" },
    { label: "Follow Up" },
    { label: "Call Not Responsive" },
  ];
  
  export default dropdownOptions;
  