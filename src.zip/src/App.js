import React, { useState } from "react";
import { Button } from "react-bootstrap";
import LeadForm from "./components/LeadForm";
import MultiLevelDropdown from "./components/MultiLevelDropdown/MultiLevelDropdown"; // ✅ Import Multi-Level Dropdown

function App() {
  const [showModal, setShowModal] = useState(false);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column", // ✅ Stack elements vertically
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
      }}
    >
      {/* ✅ Add New Lead Button */}
      <Button onClick={() => setShowModal(true)} variant="primary">
        Add New Lead
      </Button>

      {/* ✅ Space Below the Button */}
      <div style={{ marginTop: "20px" }}>
        <MultiLevelDropdown />
      </div>

      {/* ✅ LeadForm Component */}
      <LeadForm show={showModal} handleClose={() => setShowModal(false)} />
    </div>
  );
}

export default App;
